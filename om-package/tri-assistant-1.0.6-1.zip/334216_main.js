
let _sessionContexts = {};

let _userContext = undefined;

let loadWA = function (instance) {
    console.log("in loadWA");

    window.instance = instance;

    function setContext(event) {

        if (!_userContext) {
            console.log("Building user context");
            event.data.context =
                event.data.context || {};
            event.data.context.skills =
                event.data.context.skills || {};
            event.data.context.skills['main skill'] =
                event.data.context.skills['main_skill'] || {};
            event.data.context.skills['main skill'].user_defined =
                event.data.context.skills['main skill'].user_defined || {};
            event.data.context.skills['main skill'].user_defined.userContext =
                event.data.context.skills['main skill'].user_defined.userContext || {};
            event.data.context.skills['main skill'].user_defined.userContext.name =
                event.data.context.skills['main skill'].user_defined.userContext.name || {};
            event.data.context.skills['main skill'].user_defined.userContext.name.first =
                this.currentUser.firstName;
            event.data.context.skills['main skill'].user_defined.userContext.name.last =
                this.currentUser.lastName;
            event.data.context.skills['main skill'].user_defined.userContext.email =
                this.currentUser.email;
            try {
                if (this.primaryLocation.building.value) {
                    event.data.context.skills['main skill'].user_defined.userContext.location =
                        event.data.context.skills['main skill'].user_defined.userContext.location || {};
                    event.data.context.skills['main skill'].user_defined.userContext.location.building =
                        this.primaryLocation.building.value;
                }
            } catch (e) {
                // if no building value, then that's okay
            }
            _userContext = event.data.context.skills["main skill"].user_defined.userContext;
            this.sentContext = true;
        }
        //console.log("context is:", event.data.context);
    }

    function getSessionContext(bpIntegrationId) {
        if (!_sessionContexts[bpIntegrationId]) {
            _sessionContexts[bpIntegrationId] = {
                skills: {
                    "main skill": {
                        user_defined: {
                            userContext: _userContext
                        }
                    }
                }
            }
        }
        return _sessionContexts[bpIntegrationId];
    }

    function handleBP(proxyAction) {
        let body = JSON.parse(JSON.stringify(proxyAction.parameters.body));
        const bpIntegrationId = body.integration_id;
        const proxyReturnVariableName = proxyAction.result_variable;
        body.wa_payload.context = getSessionContext(bpIntegrationId);
        // Proxy needs session ID so get from last context if there
        if (body.wa_payload.context.global && body.wa_payload.context.global.session_id) {
            body.sessionId = body.wa_payload.context.global.session_id;
            delete body.wa_payload.context.global;
        } else {
            body.sessionId = "";
        }

        callProxy(
            proxyAction.parameters.bp_proxy,
            body
        ).then((result) => {

            // TODO handle invalid session for session timeout
            try {
                if (!result.result.result.output) {
                    throw Error();
                }
            } catch (e) {
                console.error("Invalid response from Assistant Proxy.  This doesn't look like a response from a Watson Assistant skill", JSON.stringify(result, null, 2));
            }
            // save state for the BP skill and send through proxy
            _sessionContexts[bpIntegrationId] = result.result.result.context;
            const output = result.result.result.output;
            if (output.actions && output.actions[0].type == "client") {
                const action = output.actions[0];
                const resultVariableName = action.result_variable;
                callBPCFwebhook(
                    action.parameters.url,
                    action.parameters.body,
                ).then((result) => {
                    if (result.userContext && result.userContext != null) {
                        _sessionContexts[bpIntegrationId].skills["main skill"].user_defined.userContext = result.userContext;
                    }
                    proxyAction.parameters.body.wa_payload.input.text = "";
                    _sessionContexts[bpIntegrationId].skills["main skill"].user_defined[resultVariableName] = result;
                    // send CF result right back to BP skill
                    handleBP(proxyAction);
                });
            } else {
                var context = {
                    "skills": {
                        "main skill": {
                            "user_defined": {
                                userContext: _userContext
                            }
                        }
                    }
                };
                context.skills["main skill"].user_defined[proxyReturnVariableName] = result.result.result;
                var sendObject = {
                    "input": {
                        "message_type": "text",
                        "text": "",
                        "options": {
                            "return_context": true
                        }
                    },
                    "context": context
                };
                var sendOptions = {
                    "silent": true
                }

                console.log('\n\x1b[32m--------TA Skill -- BP Skill reply-----------------------------------------------------------------------------------\n');
                instance.send(sendObject, sendOptions).catch(function (error) {
                    console.error('[ibmTriAssistant] This message did not send!', sendObject);
                });
                //sendMessage("", { "userContext": userContext, "bp_result": result.result.result });
            }
        });
    }

    function callProxy(url, body) {
        console.log('\n\x1b[32m--------PROXY--------------------------------------------------------------------------------------------\n');
        return post(url, body);
    }

    function callBPCFwebhook(url, body) {
        console.log('\n--------BP Fulfillment---------------------------------------------------------------------------------------\n');
        return post(url, body);
    }

    function callCFwebhook(url, body) {
        console.log('\n--------TA CF webhook----------------------------------------------------------------------------------------\n');
        return post(url, body);
    }

    function post(url, data) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', url);
            xhr.responseType = 'json';
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onload = () => {
                if (xhr.status === 200) {
                    resolve(xhr.response);
                } else {
                    reject();
                }
            };
            xhr.send(JSON.stringify(data));
        });
    }

    function promiseHandler(event) {
        //console.log("got pre:receive", event);
        try {
            if (event.data.output.actions && event.data.output.actions[0]) {
                try {
                    const action = event.data.output.actions[0];
                    if (action.type === "client") {
                        if (action.name === "bp_proxy") {
                            handleBP(event.data.output.actions[0]);
                        } else {
                            const resultVariableName = event.data.output.actions[0].result_variable;
                            if (event.data.context.skills['main skill'].user_defined[resultVariableName]) {
                                delete event.data.context.skills['main skill'].user_defined[resultVariableName];
                            }
                            callCFwebhook(
                                event.data.context.skills["main skill"].user_defined.private.cloudfunctions.webhook,
                                action.parameters)
                                .then(returned => {
                                    //console.log({ returnedXHR: returned });
                                    var context = {
                                        "skills": {
                                            "main skill": {
                                                "user_defined": {
                                                }
                                            }
                                        }
                                    };
                                    context.skills["main skill"].user_defined[resultVariableName] = returned;
                                    var sendObject = {
                                        "input": {
                                            "message_type": "text",
                                            "text": "",
                                            "options": {
                                                "return_context": true
                                            }
                                        },
                                        "context": context
                                    };
                                    var sendOptions = {
                                        "silent": true
                                    }
                                    console.log('\n\x1b[32m--------TA Skill - TA fulfillment-------------------------------------------------------------------------------------\n');
                                    instance.send(sendObject, sendOptions).catch(function (error) {
                                        console.error('[ibmTriAssistant] This message did not send!', sendObject);
                                    });
                                });
                        }
                    } else {
                        // there was an action, but wasn't type client??
                    }
                } catch (e) {
                    console.error("[ibmTriAssistant] Error when calling cloudfunction", e);
                }
            } else {
                // event isn't an action, so disregard
            }
        } catch (e) {
            console.error("looking for event.data.output.action and got this error instead:", e);
        }
    }
    instance.on({ type: "pre:send", handler: setContext.bind(this) });
    instance.on({ type: "pre:receive", handler: promiseHandler.bind(this) });
    instance.render();
}


module.exports = {
    loadWA
};